export class Plato {
    id: string;
    nombre: string;
    precio: number;
}