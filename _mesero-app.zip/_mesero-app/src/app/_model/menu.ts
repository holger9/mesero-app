export class Menu {
    idMenu: string;
    icono: string;
    nombre: string;
    url: string;
    roles: string[];
}