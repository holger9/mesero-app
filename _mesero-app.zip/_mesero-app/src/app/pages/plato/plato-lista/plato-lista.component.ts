import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Plato } from './../../../_model/plato';
import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { PlatoService } from 'src/app/_service/plato.service';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-plato-lista',
  templateUrl: './plato-lista.component.html',
  styleUrls: ['./plato-lista.component.css']
})
export class PlatoListaComponent implements OnInit, OnDestroy {

  dataSource: MatTableDataSource<Plato>
  displayedColumns = ['nombre', 'precio', 'acciones'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  private ngUnsubscribe: Subject<void> = new Subject();

  constructor(private platoService: PlatoService, private snackBar: MatSnackBar) { }

  ngOnInit() {
    //traer los platos
    this.platoService.listar().pipe(takeUntil(this.ngUnsubscribe)).subscribe(data => {

      /*data.forEach((x: any) => {
        console.log(x.payload.doc.id);
        console.log(x.payload.doc.data().nombre);
        console.log(x.payload.doc.data().precio);
      });*/
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }

  eliminar(plato: Plato) {
    this.platoService.eliminar(plato).then(() => {
      this.snackBar.open('SE ELIMINO', 'AVISO', {
        duration: 2000,
        //escriba un codigo buscando la foto y elimandola
      });
    });
  }

  
  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}

