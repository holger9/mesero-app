export class Usuario {    
    uid: string;
    email: string;
    roles: string[];
}