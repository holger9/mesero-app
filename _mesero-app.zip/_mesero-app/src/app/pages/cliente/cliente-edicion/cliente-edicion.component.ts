import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { AngularFireStorageReference, AngularFireStorage } from '@angular/fire/storage';
import { Subject } from 'rxjs';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';
import { ClienteService } from 'src/app/_service/cliente.service';
import { takeUntil } from 'rxjs/operators';
import { Cliente } from 'src/app/_model/cliente';

@Component({
  selector: 'app-cliente-edicion',
  templateUrl: './cliente-edicion.component.html',
  styleUrls: ['./cliente-edicion.component.css']
})
export class ClienteEdicionComponent implements OnInit {

  id: string;
  form: FormGroup;
  edicion: boolean;

  file: any;
  labelFile: string;
  urlImagen: string;
  
  ref: AngularFireStorageReference;

  private ngUnsubscribe: Subject<void> = new Subject();

  constructor(
    private clienteService: ClienteService, 
    private afs: AngularFirestore,
    private afStorage: AngularFireStorage,
    private route: ActivatedRoute, 
    private router: Router, 
    private snackBar: MatSnackBar) { }

  ngOnInit() {
    this.form = new FormGroup({
      'id': new FormControl(''),
      'dni': new FormControl(''),
      'nombreCompleto': new FormControl(''),
      'edad': new FormControl(0),
    });

    this.route.params.subscribe((params: Params) => {
      this.id = params['id'];
      this.edicion = this.id != null;
      this.initForm();
    });
  }

  initForm() {
    if (this.edicion) {
      this.clienteService.leer(this.id).pipe(takeUntil(this.ngUnsubscribe)).subscribe((data: Cliente) => {
        this.form = new FormGroup({
          'id': new FormControl(data.id),
          'dni': new FormControl(data.dni),
          'nombreCompleto': new FormControl(data.nombreCompleto),
          'edad': new FormControl(data.edad),
        });

        if(data.id != null){
          this.afStorage.ref(`clientes/${data.id}`).getDownloadURL().subscribe(data=> this.urlImagen = data);
        }
      });
    }
  }

  operar() {
    let nuevoCliente = new Cliente();

    if(this.edicion){
      nuevoCliente.id = this.form.value['id'];
    }else{
      nuevoCliente.id = this.afs.createId();
    }
    
    nuevoCliente.dni = this.form.value['dni'];
    nuevoCliente.nombreCompleto = this.form.value['nombreCompleto'];
    nuevoCliente.edad = this.form.value['edad'];
    let mensaje;

    //servicios de firestorage
    if(this.file != null){
      this.ref = this.afStorage.ref(`clientes/${nuevoCliente.id}`);
      this.ref.put(this.file);
    }

    if (this.edicion) {
      this.clienteService.actualizar(nuevoCliente);
      mensaje = 'SE MODIFICO CLIENTE';
    } else {
      this.clienteService.registrar(nuevoCliente);
      mensaje = 'SE REGISTRO CLIENTE';
    }

    this.snackBar.open(mensaje, 'AVISO', {
      duration: 2000
    });
    this.router.navigate(['cliente']);
  }

  seleccionar(e: any){
    this.file = e.target.files[0];
    this.labelFile = e.target.files[0].name;
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

}
