import { ConsumoService } from './../../_service/consumo.service';
import { Consumo } from './../../_model/consumo';
import { PlatoService } from 'src/app/_service/plato.service';
import { ClienteService } from './../../_service/cliente.service';
import { Detalle } from './../../_model/detalle';
import { Plato } from './../../_model/plato';
import { Cliente } from './../../_model/cliente';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatInput, MatSnackBar } from '@angular/material';
import { map, takeUntil } from 'rxjs/operators';
import { Observable, Subject } from 'rxjs';
import { AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-consumo',
  templateUrl: './consumo.component.html',
  styleUrls: ['./consumo.component.css']
})
export class ConsumoComponent implements OnInit, OnDestroy {

  form: FormGroup;
  myControlCliente: FormControl = new FormControl();
  myControlPlato: FormControl = new FormControl();

  filteredClientes: Observable<any[]>;
  filteredPlatos: Observable<any[]>;

  clientes: Cliente[] = [];
  platos: Plato[] = [];
  detalle: Detalle[] = [];
  cantidad: number;
  cliente: Cliente;
  plato: Plato;  

  dataSource: MatTableDataSource<Detalle>;
  displayedColumns = ['nombre', 'precio', 'cantidad', 'subtotal', 'acciones'];
  total: number = 0;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;  

  private ngUnsubscribe: Subject<void> = new Subject();

  constructor(
    private builder: FormBuilder, 
    private clienteService: ClienteService, 
    private platoService: PlatoService, 
    private consumoService: ConsumoService, 
    private snackBar: MatSnackBar,
    private afs : AngularFirestore
    ) { }

  ngOnInit() {
    this.form = this.builder.group({
      'cliente': this.myControlCliente,
      'plato': this.myControlPlato,
      'fecha': new FormControl(new Date()),
      'cantidad': new FormControl(0)
    });

    this.listarClientes();
    this.listarPlatos();

    this.filteredClientes = this.myControlCliente.valueChanges.pipe(map(val => this.filtrarClientes(val)));
    this.filteredPlatos = this.myControlPlato.valueChanges.pipe(map(val => this.filtrarPlatos(val)));
  }

  listarClientes() {
    this.clienteService.listar().pipe(takeUntil(this.ngUnsubscribe)).subscribe(data => {
      this.clientes = data;
    });
  }

  listarPlatos() {
    this.platoService.listar().pipe(takeUntil(this.ngUnsubscribe)).subscribe(data => {
      this.platos = data;
    });
  }

  filtrarClientes(val: any) {
    if (val != null && val.dni != null) {
      //console.log('bloque1');
      return this.clientes.filter(option =>
        option.nombreCompleto.toLowerCase().includes(val.nombreCompleto.toLowerCase()) || option.dni.includes(val.dni));
    } else {
      //console.log('bloque2');
      return this.clientes.filter(option =>
        option.nombreCompleto.toLowerCase().includes(val.toLowerCase()) || option.dni.includes(val));
    }
  }

  filtrarPlatos(val: any) {
    if (val != null && val.nombre != null) {
      return this.platos.filter(option =>
        option.nombre.toLowerCase().includes(val.nombre.toLowerCase()));
    } else {
      return this.platos.filter(option =>
        option.nombre.toLowerCase().includes(val.toLowerCase()));
    }
  }

  seleccionarCliente(e: any) {
    this.cliente = e.option.value;    
    this.myControlCliente.disable();
  }

  seleccionarPlato(e: any) {
    this.plato = e.option.value;
  }

  displayFnCliente(val: Cliente) {
    return val ? `${val.nombreCompleto}` : val;
  }

  displayFnPlato(val: Plato) {
    return val ? `${val.nombre}` : val;
  }

  agregar() {
    let det = new Detalle();
    det.plato = this.plato;
    det.cantidad = this.cantidad;
    this.detalle.push(det);

    this.total += det.plato.precio * det.cantidad;

    this.dataSource = new MatTableDataSource(this.detalle);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  remover(det: Detalle) {
    this.total -= det.plato.precio * det.cantidad;

    //Para poder buscar la posicion independiente del paginado
    let indices = [];
    for (let i = 0; i < this.detalle.length; i++) {
      this.detalle[i].index = i;
      indices.push(i);
      //console.log(indices);
    }
    let index = indices.indexOf(det.index);

    this.detalle.splice(index, 1);

    this.dataSource = new MatTableDataSource(this.detalle);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  aceptar() {
    let consumo = new Consumo();
    consumo.detalle = this.detalle;
    consumo.fechaPedido = new Date();
    consumo.total = this.total;

    if (this.cliente == undefined) {
      this.cliente = new Cliente();
      let nombreCompleto = this.form.value['cliente'];
      this.cliente.nombreCompleto = nombreCompleto;
      this.cliente.dni = '0000000';
      this.cliente.edad = 0;
      this.cliente.id = this.afs.createId();
      this.clienteService.registrar(JSON.parse(JSON.stringify(this.cliente))).then(data => {
        consumo.cliente = this.cliente;
        this.consumoService.registrar(consumo).then(() => {

          this.emitirMensaje();
  
          setTimeout(() => {
            this.limpiar();
          }, 2000);
        });
      });
    } else {
      consumo.cliente = this.cliente;
      this.consumoService.registrar(consumo).then(() => {

        this.emitirMensaje();

        setTimeout(() => {
          this.limpiar();
        }, 2000);
      });
    }
  }

  aceptarTransaccion() {
    let consumo = new Consumo();
    consumo.detalle = this.detalle;
    consumo.fechaPedido = new Date();
    consumo.total = this.total;

    if (this.cliente === undefined) {
      this.cliente = new Cliente();
      let nombreCompleto = this.form.value['cliente'];
      this.cliente.nombreCompleto = nombreCompleto;
      this.cliente.dni = '0000000';
      this.cliente.edad = 0;

      this.consumoService.registrarTransaccion(consumo, this.cliente).then(() => {
        this.emitirMensaje();
        setTimeout(() => {
          this.limpiar();
        }, 2000);
        this.myControlCliente.enable();
      }); 

    }
    else{
      consumo.cliente = this.cliente;
      this.consumoService.registrarTransaccion(consumo).then(() => {
        this.emitirMensaje();
        setTimeout(() => {
          this.limpiar();
        }, 2000);
        this.myControlCliente.enable();
      }); 
    }   

    /*consumo.cliente = this.cliente;

    this.consumoService.registrarTransaccion(consumo, this.cliente).then(() => {

      this.emitirMensaje();

      setTimeout(() => {
        this.limpiar();
      }, 2000);
    });*/

  }

  limpiar() {
    this.detalle = [];
    this.dataSource = new MatTableDataSource(this.detalle);
    this.cliente = undefined;
    this.total = 0;

    this.myControlCliente = new FormControl();
    this.myControlPlato = new FormControl();

    /*this.form = this.builder.group({
      'cliente': this.myControlCliente,
      'plato': this.myControlPlato,
      'fecha': new FormControl(new Date()),
      'cantidad': new FormControl(0),
    });*/
    this.ngOnInit();

  }

  emitirMensaje() {
    this.snackBar.open("Se registró exitosamente", 'AVISO', {
      duration: 2000,
    });
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

}
