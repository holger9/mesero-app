import { Menu } from './../_model/menu';
import { map, switchMap } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { LoginService } from './login.service';
import { MenuService } from './menu.service';
import { AngularFireAuth } from '@angular/fire/auth';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginGuardService implements CanActivate {

  constructor(private loginService: LoginService, private router: Router, private menuService: MenuService, private afa: AngularFireAuth) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.afa.authState
      .pipe(map(authState => !!authState))
      .pipe(switchMap((auntenticado: boolean) => {
        if (!auntenticado) {
          this.router.navigate(['/login']);
          return of(false);
        } else {

          let url = state.url;
          return this.menuService.listar().pipe(switchMap((menus) => {
            console.log(menus);
            return this.loginService.user.pipe(map(data => {
              if (data) {
                let user_roles: string[] = data.roles;
                let final_menus: Menu[] = [];

                for (let menu of menus) {
                  n2: for (let rol of menu.roles) {
                    for (let urol of user_roles) {
                      if (rol === urol) {
                        let m = new Menu();
                        m.nombre = menu.nombre;
                        m.icono = menu.icono;
                        m.url = menu.url;
                        final_menus.push(m);
                        break n2;
                      }
                    }
                  }
                }

                //console.log(final_menus);
                this.menuService.menuCambio.next(final_menus);

                //los menus de una persona vs la URL que quiere acceder
                let cont = 0;
                for (let m of final_menus) {
                  if (m.url === url) {
                    cont++;
                    break;
                  }
                }

                if (cont > 0) {
                  return true;
                }else{
                  this.router.navigate(['not-401']);
                  return false;
                }

              }
            }));
          }));
        }
      }));
  }
}
