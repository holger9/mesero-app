import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Injectable, OnDestroy } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { auth } from 'firebase/app';
import { Usuario } from '../_model/usuario';
import { Observable, EMPTY, Subject } from 'rxjs';
import { switchMap, takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginService implements OnDestroy {

  user: Observable<Usuario>;
  private ngUnsubscribe: Subject<void> = new Subject();

  constructor(private afa: AngularFireAuth, private afs: AngularFirestore, private router:Router) {
    this.user = this.afa.authState.pipe(
      switchMap(user => {
        if (user) {
          return this.afs.doc<Usuario>(`usuarios/${user.uid}`).valueChanges();
        } else {
          return EMPTY;
        }
      })
    );

  }

  login(usuario: string, clave: string) {
    return this.afa.auth.signInWithEmailAndPassword(usuario, clave).then(res => {
      return this.actualizarUsuarioData(res.user);
    });
  }

  loginFacebook() {
    const provider = new auth.FacebookAuthProvider();
    return this.oAuthLogin(provider);
  }

  loginGoogle() {
    const provider = new auth.GoogleAuthProvider();
    return this.oAuthLogin(provider);
  }

  private oAuthLogin(provider: any) {
    return this.afa.auth.signInWithPopup(provider).then((credencial) => {
      console.log(credencial);
      this.actualizarUsuarioData(credencial.user);
    });
  }

  restablecerClave(email: string) {
    return this.afa.auth.sendPasswordResetEmail(email);
  }

  registrarUsuario(usuario: string, clave: string) {
    return this.afa.auth.createUserWithEmailAndPassword(usuario, clave);
  }

  estaLogeado(){
    return this.afa.auth.currentUser != null;
  }

  private actualizarUsuarioData(usuario) {
    const userRef: AngularFirestoreDocument<Usuario> = this.afs.doc(`usuarios/${usuario.uid}`);

    userRef.valueChanges().pipe(takeUntil(this.ngUnsubscribe)).subscribe(data => {
      if (data) {
        const datos: Usuario = {
          uid: usuario.uid,
          email: usuario.email,
          roles: data.roles
        }
        return userRef.set(datos);
      } else {
        const datos: Usuario = {
          uid: usuario.uid,
          email: usuario.email,
          roles: ['USER']
        }
        return userRef.set(datos);
      }
    });
  }

  cerrarSesion(){
    return this.afa.auth.signOut().then( () => {
      //window.location.reload();
      this.router.navigate(['login']);
    });
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
