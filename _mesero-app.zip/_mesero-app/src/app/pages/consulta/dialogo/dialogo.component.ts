import { Consumo } from './../../../_model/consumo';
import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AngularFireStorage } from '@angular/fire/storage';

@Component({
  selector: 'app-dialogo',
  templateUrl: './dialogo.component.html',
  styleUrls: ['./dialogo.component.css']
})
export class DialogoComponent implements OnInit {

  consumo: Consumo;
  urlImagen: any;
  i: any;

  constructor(private dialogRef: MatDialogRef<DialogoComponent>, @Inject(MAT_DIALOG_DATA) public data: Consumo, private afStorage: AngularFireStorage) { }

  ngOnInit() {
    this.consumo = this.data;
    this.afStorage.ref(`clientes/${this.data.cliente.id}`).getDownloadURL().subscribe(data=> this.urlImagen = data);
    console.log(this.urlImagen);
  }

  cerrar(){
    this.dialogRef.close();
  }

}
