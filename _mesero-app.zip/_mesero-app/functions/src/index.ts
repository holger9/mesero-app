import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as cors from 'cors';

// // Start writing Firebase Functions
// // https://firebase.google.com/docs/functions/typescript
//

const corsHandler = cors({ origin: true });

admin.initializeApp();

export const helloWithCorsAllowed = functions.https.onRequest((req, res) => {
  corsHandler(req, res, () => {
    let requestUid = req.body.uid;
    let authToken = validarCabecera(req);

    if (!authToken) {
      return res.status(403).send('{ "mensaje" : "prohibido" }');
    }

    return decodificarToken(authToken)
      .then(uid => {
        console.log('UID' + uid);
        if (uid === requestUid) {
          return res.status(200).send('{ "mensaje" : "exito" }');
        } else {
          return res.status(403).send('{ "mensaje" : "prohibido" }');
        }
      });
  });
});

function validarCabecera(req: any) {
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    //console.log('auth header found')
    return req.headers.authorization.split('Bearer ')[1]
  }
}

function decodificarToken(authToken: any) {
  return admin.auth().verifyIdToken(authToken)
    .then(tokenDecodificado => {
      return tokenDecodificado.uid;
    });
}

export const helloWorld = functions.https.onRequest((request, response) => {
  response.send("Hello from Firebase!");
});

const storage = admin.storage();
export const removerFoto = functions.firestore
  .document('platos/{id}')
  .onDelete((snap, context) => {
    const id = context.params.id;
    console.log('IDSTORAGE: ' + id);

    const bucket = storage.bucket();
    const file = bucket.file(`platos/${id}`);

    return file.delete();
  });

  export const removerFotoCliente = functions.firestore
  .document('clientes/{id}')
  .onDelete((snap, context) => {
    const id = context.params.id;
    console.log('IDSTORAGECLIENTE: ' + id);

    const bucket = storage.bucket();
    const file = bucket.file(`clientes/${id}`);

    return file.delete();
  });
