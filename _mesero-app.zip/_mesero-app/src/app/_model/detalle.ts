import { Plato } from './plato';

export class Detalle {
    id: string;
    plato: Plato;
    cantidad: number;

    index: number;
}