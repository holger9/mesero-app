import { Subject } from 'rxjs';
import { LoginService } from './_service/login.service';
import { Menu } from './_model/menu';
import { MenuService } from './_service/menu.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  menus: Menu[] = [];
  private ngUnsubscribe: Subject<void> = new Subject();

  constructor(private menuService: MenuService, public loginService : LoginService) {

  }

  ngOnInit() {
    this.menuService.menuCambio.pipe(takeUntil(this.ngUnsubscribe)).subscribe(data => {
      this.menus = data;
    });
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
