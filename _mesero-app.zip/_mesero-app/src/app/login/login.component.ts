import { Subject } from 'rxjs';
import { Menu } from './../_model/menu';
import { MenuService } from './../_service/menu.service';
import { LoginService } from './../_service/login.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { auth } from 'firebase/app';
import { Router } from '@angular/router';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {

  usuario: string;
  clave: string;
  mensaje: string;
  mensajeRestablecer: string;
  mensajeCrear: string;

  estadoLogin: boolean = true;
  estadoRecuperar: boolean;
  estadoCrear: boolean;
  private ngUnsubscribe: Subject<void> = new Subject();

  constructor(private loginService: LoginService, private router: Router, private menuService: MenuService) { }

  ngOnInit() {
  }



  login() {
    this.loginService.login(this.usuario, this.clave).then(data => {
      this.listarMenus();
    });
  }


  loginGoogle() {
    this.loginService.loginGoogle().then(() => {
      this.listarMenus();
    });
  }

  loginFacebook() {
    this.loginService.loginFacebook().then(() => {
      this.listarMenus();
    }).catch(err => {
      if (err.code === 'auth/account-exists-with-different-credential') {
        let facebookCred = err.credential;
        let googleProvider = new auth.GoogleAuthProvider();
        googleProvider.setCustomParameters({ 'login_hint': err.email });

        this.listarMenus();

        return auth().signInWithPopup(googleProvider).then(result => {
          return result.user.linkWithCredential(facebookCred);
        });
      }
    });
  }

  recuperar() {
    this.estadoRecuperar = true;
    this.estadoLogin = false;
  }

  crear() {
    this.estadoCrear = true;
    this.estadoLogin = false;
  }


  irLogin() {
    this.estadoLogin = true;
    this.estadoRecuperar = false;
    this.estadoCrear = false;
  }

  crearUsuario() {
    this.loginService.registrarUsuario(this.usuario, this.clave);
  }

  restablecerClave() {
    this.loginService.restablecerClave(this.usuario).then(data => console.log(data));
  }

  listarMenus() {
    this.menuService.listar().pipe(takeUntil(this.ngUnsubscribe)).subscribe(menus => {

      this.loginService.user.pipe(takeUntil(this.ngUnsubscribe)).subscribe(userData => {
        if (userData) {
          //console.log(userData);
          let user_roles: string[] = userData.roles
          let final_menus: Menu[] = [];

          for (let menu of menus) {
            n2: for (let rol of menu.roles) {
              for (let urol of user_roles) {
                if (rol === urol) {
                  let m = new Menu();
                  m.nombre = menu.nombre;
                  m.icono = menu.icono;
                  m.url = menu.url;
                  final_menus.push(m);
                  break n2;
                }
              }
            }

            this.menuService.menuCambio.next(final_menus);
            this.router.navigate(['plato']);
          }
        }
      });
    });
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
