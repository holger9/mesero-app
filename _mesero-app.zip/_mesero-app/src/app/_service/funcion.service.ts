import { AngularFireAuth } from '@angular/fire/auth';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FuncionService {

  constructor(private http: HttpClient, private afa: AngularFireAuth) { }

  probar() {
    //const url = "https://us-central1-mesero-app2.cloudfunctions.net/helloWithCorsAllowed";
    const url = "https://us-central1-mesero-app-5343a.cloudfunctions.net/helloWithCorsAllowed";

    return this.afa.auth.currentUser.getIdToken().then(authToken => {
      const headers = new HttpHeaders({ 'Authorization': 'Bearer ' + authToken });

      const myUID = { uid: this.afa.auth.currentUser.uid };

      return this.http.post(url, myUID, { headers: headers }).toPromise();
    });
  }
}
