import { Subject } from 'rxjs';
import { AngularFirestore } from '@angular/fire/firestore';
import { PlatoService } from 'src/app/_service/plato.service';
import { Plato } from './../../../_model/plato';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { AngularFireStorage, AngularFireStorageReference } from '@angular/fire/storage';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-plato-edicion',
  templateUrl: './plato-edicion.component.html',
  styleUrls: ['./plato-edicion.component.css']
})
export class PlatoEdicionComponent implements OnInit, OnDestroy {

  id: string;
  form: FormGroup;
  edicion: boolean;

  file: any;
  labelFile: string;
  urlImagen: string;
  
  ref: AngularFireStorageReference;

  private ngUnsubscribe: Subject<void> = new Subject();
  
  constructor(
    private platoService: PlatoService, 
    private afs: AngularFirestore,
    private afStorage: AngularFireStorage,
    private route: ActivatedRoute, 
    private router: Router, 
    private snackBar: MatSnackBar) { }

  ngOnInit() {
    this.form = new FormGroup({
      'id': new FormControl(''),
      'nombre': new FormControl(''),
      'precio': new FormControl(0),
    });

    this.route.params.subscribe((params: Params) => {
      this.id = params['id'];
      this.edicion = this.id != null;
      this.initForm();
    });
  }

  initForm() {
    if (this.edicion) {
      this.platoService.leer(this.id).pipe(takeUntil(this.ngUnsubscribe)).subscribe((data: Plato) => {
        this.form = new FormGroup({
          'id': new FormControl(data.id),
          'nombre': new FormControl(data.nombre),
          'precio': new FormControl(data.precio),
        });

        if(data.id != null){
          this.afStorage.ref(`platos/${data.id}`).getDownloadURL().subscribe(data=> this.urlImagen = data);
        }
      });
    }
  }

  operar() {
    let nuevoPlato = new Plato();

    if(this.edicion){
      nuevoPlato.id = this.form.value['id'];
    }else{
      nuevoPlato.id = this.afs.createId();
    }
    
    nuevoPlato.nombre = this.form.value['nombre'];
    nuevoPlato.precio = this.form.value['precio'];
    let mensaje;

    //servicios de firestorage
    if(this.file != null){
      this.ref = this.afStorage.ref(`platos/${nuevoPlato.id}`);
      this.ref.put(this.file);
    }

    if (this.edicion) {
      this.platoService.modificar(nuevoPlato);
      mensaje = 'SE MODIFICO';
    } else {
      this.platoService.registrar(nuevoPlato);
      mensaje = 'SE REGISTRO';
    }

    this.snackBar.open(mensaje, 'AVISO', {
      duration: 2000
    });
    this.router.navigate(['plato']);
  }

  seleccionar(e: any){
    this.file = e.target.files[0];
    this.labelFile = e.target.files[0].name;
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
