import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar } from '@angular/material';
import { Cliente } from 'src/app/_model/cliente';
import { ClienteService } from 'src/app/_service/cliente.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { AngularFireStorage } from '@angular/fire/storage';
import { AngularFireAuth } from '@angular/fire/auth';


@Component({
  selector: 'app-cliente-lista',
  templateUrl: './cliente-lista.component.html',
  styleUrls: ['./cliente-lista.component.css']
})
export class ClienteListaComponent implements OnInit {

  dataSource: MatTableDataSource<Cliente>
  displayedColumns = ['dni', 'nombreCompleto', 'edad', 'acciones'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  private ngUnsubscribe: Subject<void> = new Subject();

  constructor(
    private clienteService: ClienteService, 
    private snackBar: MatSnackBar, 
    private afStorage: AngularFireStorage
    ) { }

  ngOnInit() {
    //traer los clientes
    this.clienteService.listar().pipe(takeUntil(this.ngUnsubscribe)).subscribe(data => {
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }

  eliminar(cliente: Cliente) {
    this.clienteService.eliminar(cliente).then(() => {
      this.snackBar.open('SE ELIMINO CLIENTE', 'AVISO', {
        duration: 2000,
        //escriba un codigo buscando la foto y elimandola        
      });
    });
  }
 
  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

}
