import { ClienteService } from './../../_service/cliente.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ReporteService } from 'src/app/_service/reporte.service';
import * as moment from 'moment';
import { Chart } from 'chart.js';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-reporte',
  templateUrl: './reporte.component.html',
  styleUrls: ['./reporte.component.css']
})
export class ReporteComponent implements OnInit, OnDestroy {

  chart: any;
  tipo: string;
  private ngUnsubscribe: Subject<void> = new Subject();

  constructor(private reporteService: ReporteService, private clienteService: ClienteService) { }

  ngOnInit() {
    this.tipo = 'bar';
    this.dibujarCliente();

    this.reporteService.buscarConsumosClienteIden().pipe(takeUntil(this.ngUnsubscribe)).subscribe(data => console.log(data));
  }

  dibujar() {
    let fecha = new Date();
    fecha.setFullYear(2019);
    fecha.setMonth(3);
    fecha.setDate(8);
    fecha.setMinutes(0);
    fecha.setHours(0);
    fecha.setSeconds(0);
    this.reporteService.buscarPorFeha(fecha).pipe(takeUntil(this.ngUnsubscribe)).subscribe((data: any) => {

      let fechas = data.map(res => moment(res.fechaPedido.toDate()).format('DD-MM-YYYY HH:mm:ss'));
      let total = data.map(res => res.total);
      
      this.chart = new Chart('canvas', {
        type: this.tipo,
        data: {
          labels: fechas,
          datasets: [
            {
              label: 'Total',
              data: total,
              borderColor: "#3cba9f",
              fill: false,
              backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 0, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 99, 132, 0.2)'
              ]
            }
          ]
        },
        options: {
          legend: {
            display: false
          },
          scales: {
            xAxes: [{
              display: true
            }],
            yAxes: [{
              display: true
            }],
          }
        }
      });

    });
  }

  dibujarCliente() {
    this.clienteService.listar().pipe(takeUntil(this.ngUnsubscribe)).subscribe(data => {
      let nombres = data.map(res => res.nombreCompleto);
      let edad = data.map(res => res.edad);

      this.chart = new Chart('canvas', {
        type: this.tipo,
        data: {
          labels: nombres,
          datasets: [
            {
              label: 'Nombre',
              data: edad,
              borderColor: "#3cba9f",
              fill: false,
              backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 0, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 0, 0.2)',
                'rgba(255, 159, 64, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 0, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 0, 0.2)',
                'rgba(75, 192, 192, 0.2)',
              ]
            }
          ]
        },
        options: {
          legend: {
            display: false
          },
          scales: {
            xAxes: [{
              display: true
            }],
            yAxes: [{
              display: true
            }],
          }
        }
      });
    });
  }

  cambiar(tipo: string) {
    this.tipo = tipo;
    if (this.chart) {
      this.chart.destroy();
    }
    //this.dibujar();
    this.dibujarCliente();
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
