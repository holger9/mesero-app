export const environment = {
  production: true,
  /*firebase: {
    apiKey: "TU_API_KEY",
    authDomain: "mesero-app2.firebaseapp.com",
    databaseURL: "https://mesero-app2.firebaseio.com",
    projectId: "mesero-app2",
    storageBucket: "mesero-app2.appspot.com",
    messagingSenderId: "14600204906"
  }*/  
  firebase: {
    apiKey: "AIzaSyDzRoV_8HUo4jiHtaIt927uTsyqJJwR-YM",
    authDomain: "mesero-app-5343a.firebaseapp.com",
    databaseURL: "https://mesero-app-5343a.firebaseio.com",
    projectId: "mesero-app-5343a",
    storageBucket: "mesero-app-5343a.appspot.com",
    messagingSenderId: "932611808585"
  }
};
