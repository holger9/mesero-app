import { Subject } from 'rxjs';
import { LoginService } from './../../_service/login.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-not401',
  templateUrl: './not401.component.html',
  styleUrls: ['./not401.component.css']
})
export class Not401Component implements OnInit, OnDestroy {

  usuario: string;
  private ngUnsubscribe: Subject<void> = new Subject();

  constructor(private loginService: LoginService) { }

  ngOnInit() {
    
    this.loginService.user.pipe(takeUntil(this.ngUnsubscribe)).subscribe(data => {
      this.usuario = data.email;
    });    
  }

  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
