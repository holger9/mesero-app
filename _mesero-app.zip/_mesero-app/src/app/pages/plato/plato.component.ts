import { FuncionService } from './../../_service/funcion.service';
import { Plato } from './../../_model/plato';
import { PlatoService } from './../../_service/plato.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plato',
  templateUrl: './plato.component.html',
  styleUrls: ['./plato.component.css']
})
export class PlatoComponent implements OnInit {


  constructor(private funcionService : FuncionService) { }

  ngOnInit() {
    this.funcionService.probar().then(data => console.log(data));
    
  }

}
